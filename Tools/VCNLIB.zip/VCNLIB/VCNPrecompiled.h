///
/// Copyright (C) 2012 - All Rights Reserved
/// All rights reserved. http://www.equals-forty-two.com
/// 

#ifndef GLOBALS_H
#define GLOBALS_H

#pragma once

// STL includes
#include <unordered_map>

#endif // GLOBALS_H
