// This code contains NVIDIA Confidential Information and is disclosed to you 
// under a form of NVIDIA software license agreement provided separately to you.
//
// Notice
// NVIDIA Corporation and its licensors retain all intellectual property and
// proprietary rights in and to this software and related documentation and 
// any modifications thereto. Any use, reproduction, disclosure, or 
// distribution of this software and related documentation without an express 
// license agreement from NVIDIA Corporation is strictly prohibited.
// 
// ALL NVIDIA DESIGN SPECIFICATIONS, CODE ARE PROVIDED "AS IS.". NVIDIA MAKES
// NO WARRANTIES, EXPRESSED, IMPLIED, STATUTORY, OR OTHERWISE WITH RESPECT TO
// THE MATERIALS, AND EXPRESSLY DISCLAIMS ALL IMPLIED WARRANTIES OF NONINFRINGEMENT,
// MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Information and code furnished is believed to be accurate and reliable.
// However, NVIDIA Corporation assumes no responsibility for the consequences of use of such
// information or for any infringement of patents or other rights of third parties that may
// result from its use. No license is granted by implication or otherwise under any patent
// or patent rights of NVIDIA Corporation. Details are subject to change without notice.
// This code supersedes and replaces all information previously supplied.
// NVIDIA Corporation products are not authorized for use as critical
// components in life support devices or systems without express written approval of
// NVIDIA Corporation.
//
// Copyright (c) 2008-2012 NVIDIA Corporation. All rights reserved.
// Copyright (c) 2004-2008 AGEIA Technologies, Inc. All rights reserved.
// Copyright (c) 2001-2004 NovodeX AG. All rights reserved.  

#include "PxPhysX.h"

#if PX_USE_CLOTH_API

#include "PhysXSample.h"

#include "SampleCharacterClothCameraController.h"

#include "SampleCharacterCloth.h"
#include "SampleCharacterClothInputEventIds.h"
#include "SampleUtils.h"

#include "PxRigidDynamic.h"
#include "foundation/PxMath.h"
#include <SampleBaseInputEventIds.h>
#include <SamplePlatform.h>
#include <SampleUserInput.h>
#include <SampleUserInputIds.h>
#include <SampleUserInputDefines.h>

using namespace physx;
using namespace SampleRenderer;
using namespace SampleFramework;

///////////////////////////////////////////////////////////////////////////////
SampleCharacterClothCameraController::SampleCharacterClothCameraController(PxController& controlled, SampleCharacterCloth& base) :
	mCamera						(NULL),
	mController						(controlled),
	mSample						(base),
	mTargetYaw					(0.0f-PxPi/2),
	mTargetPitch				(0.0f),
	mPitchMin					(-PxHalfPi),
	mPitchMax					(PxHalfPi),
	mGamepadPitchInc			(0.0f),
	mGamepadYawInc				(0.0f),
	mGamepadForwardInc			(0.0f),
	mGamepadLateralInc			(0.0f),
	mSensibility				(0.01f),
	mFwd						(false),
	mBwd						(false),
	mLeft						(false),
	mRight						(false),
	mKeyShiftDown				(false),
	mRunningSpeed				(8.0f),
	mWalkingSpeed				(4.0f)
{
}

//////////////////////////////////////////////////////////////////////////

void SampleCharacterClothCameraController::collectInputEvents(std::vector<const SampleFramework::InputEvent*>& inputEvents)
{
	//digital keyboard events
	DIGITAL_INPUT_EVENT_DEF(CAMERA_MOVE_FORWARD,	SCAN_CODE_FORWARD,		XKEY_W,					PS3KEY_W,				AKEY_UNKNOWN,	SCAN_CODE_FORWARD,	PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	SCAN_CODE_FORWARD);
	DIGITAL_INPUT_EVENT_DEF(CAMERA_MOVE_BACKWARD,	SCAN_CODE_BACKWARD,		XKEY_S,					PS3KEY_S,				AKEY_UNKNOWN,	SCAN_CODE_BACKWARD,	PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	SCAN_CODE_BACKWARD);
	DIGITAL_INPUT_EVENT_DEF(CAMERA_MOVE_LEFT,		SCAN_CODE_LEFT,			XKEY_A,					PS3KEY_A,				AKEY_UNKNOWN,	SCAN_CODE_LEFT,		PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	SCAN_CODE_LEFT);
	DIGITAL_INPUT_EVENT_DEF(CAMERA_MOVE_RIGHT,		SCAN_CODE_RIGHT,		XKEY_D,					PS3KEY_D,				AKEY_UNKNOWN,	SCAN_CODE_RIGHT,	PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	SCAN_CODE_RIGHT);
	DIGITAL_INPUT_EVENT_DEF(CAMERA_SHIFT_SPEED,		SCAN_CODE_LEFT_SHIFT,	XKEY_SHIFT,				PS3KEY_SHIFT,			AKEY_UNKNOWN,	OSXKEY_SHIFT,		PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	LINUXKEY_SHIFT);
	DIGITAL_INPUT_EVENT_DEF(CAMERA_JUMP,			SCAN_CODE_SPACE,		XKEY_SPACE,				PS3KEY_SPACE,			AKEY_UNKNOWN,	OSXKEY_SPACE,		PSP2KEY_UNKNOWN,	IKEY_UNKNOWN,	LINUXKEY_SPACE);

	//digital gamepad events
	DIGITAL_INPUT_EVENT_DEF(CAMERA_JUMP,			GAMEPAD_SOUTH,	GAMEPAD_SOUTH,	GAMEPAD_SOUTH,	AKEY_UNKNOWN,	GAMEPAD_SOUTH,	GAMEPAD_SOUTH,	IKEY_UNKNOWN,	LINUXKEY_UNKNOWN);

	//analog gamepad events
	ANALOG_INPUT_EVENT_DEF(CAMERA_GAMEPAD_ROTATE_LEFT_RIGHT,GAMEPAD_ROTATE_SENSITIVITY,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X,	GAMEPAD_RIGHT_STICK_X, 	LINUXKEY_UNKNOWN);
	ANALOG_INPUT_EVENT_DEF(CAMERA_GAMEPAD_ROTATE_UP_DOWN,GAMEPAD_ROTATE_SENSITIVITY,		GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y,	GAMEPAD_RIGHT_STICK_Y, 	LINUXKEY_UNKNOWN);
	ANALOG_INPUT_EVENT_DEF(CAMERA_GAMEPAD_MOVE_LEFT_RIGHT,GAMEPAD_DEFAULT_SENSITIVITY,		GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X,	GAMEPAD_LEFT_STICK_X, 	LINUXKEY_UNKNOWN);
	ANALOG_INPUT_EVENT_DEF(CAMERA_GAMEPAD_MOVE_FORWARD_BACK,GAMEPAD_DEFAULT_SENSITIVITY,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y,	GAMEPAD_LEFT_STICK_Y, 	LINUXKEY_UNKNOWN);

    //touch events
    TOUCH_INPUT_EVENT_DEF(CAMERA_JUMP,	"Jump",	AQUICK_BUTTON_1,	IQUICK_BUTTON_1);
}

///////////////////////////////////////////////////////////////////////////////
void SampleCharacterClothCameraController::onDigitalInputEvent(const SampleFramework::InputEvent& ie, bool val)
{
	switch (ie.m_Id)
	{
	case CAMERA_MOVE_FORWARD:
		{
			mFwd = val;
		}
		break;
	case CAMERA_MOVE_BACKWARD:
		{
			mBwd = val;
		}
		break;
	case CAMERA_MOVE_LEFT:
		{
			mLeft = val;
		}
		break;
	case CAMERA_MOVE_RIGHT:
		{
			mRight = val;
		}
		break;
	case CAMERA_SHIFT_SPEED:
		{
			mKeyShiftDown = val;
		}
		break;
	case CAMERA_JUMP:
		{
			if(val)
				mSample.mJump.startJump(13.0f);
		}
		break;
	}
}

///////////////////////////////////////////////////////////////////////////////
static PX_FORCE_INLINE PxReal remapAxisValue(PxReal absolutePosition)
{
	return absolutePosition * absolutePosition * absolutePosition * 5.0f;
}

///////////////////////////////////////////////////////////////////////////////
void SampleCharacterClothCameraController::onAnalogInputEvent(const SampleFramework::InputEvent& ie, float val)
{
	if(ie.m_Id == CAMERA_GAMEPAD_ROTATE_LEFT_RIGHT)
	{
		mGamepadYawInc = - remapAxisValue(val);
	}
	else if(ie.m_Id == CAMERA_GAMEPAD_ROTATE_UP_DOWN)
	{
		mGamepadPitchInc = - remapAxisValue(val);
	}
	else if(ie.m_Id == CAMERA_GAMEPAD_MOVE_LEFT_RIGHT)
	{
		mGamepadLateralInc = -val;
	}
	else if(ie.m_Id == CAMERA_GAMEPAD_MOVE_FORWARD_BACK)
	{
		mGamepadForwardInc = val;
	}
}

///////////////////////////////////////////////////////////////////////////////
void SampleCharacterClothCameraController::onPointerInputEvent(const SampleFramework::InputEvent &ie, physx::PxU32, physx::PxU32, physx::PxReal dx, physx::PxReal dy, bool val)
{
	if (ie.m_Id == CAMERA_MOUSE_LOOK)
	{
		mTargetYaw		-= dx * mSensibility;
		mTargetPitch	+= dy * mSensibility;
	}
}

///////////////////////////////////////////////////////////////////////////////
void SampleCharacterClothCameraController::setView(PxReal pitch, PxReal yaw)
{
	mTargetPitch = pitch;
	mTargetYaw   = yaw;
}

///////////////////////////////////////////////////////////////////////////////
// This function gets called whenever camera needs to be updated
void SampleCharacterClothCameraController::update(Camera& camera, PxReal dtime)
{
	mCamera = &camera;
	updateFromCCT(dtime);
}

///////////////////////////////////////////////////////////////////////////////
void  
SampleCharacterClothCameraController::updateFromCCT(PxReal dtime)
{
	if(!mSample.isPaused())
	{
		PxVec3 disp(0);

		if (mFwd || mBwd || mRight || mLeft || (fabsf(mGamepadForwardInc) > 0.1f) || (fabsf(mGamepadLateralInc) > 0.1f))
		{
			PxVec3 targetKeyDisplacement(0);
			PxVec3 targetPadDisplacement(0);

			// compute basis
			PxVec3 forward = mCamera->getViewDir();
			forward.y = 0;
			forward.normalize();
			PxVec3 up = PxVec3(0,1,0);
			PxVec3 right = forward.cross(up);
			computeBasis(forward, right, up);

			// increase target displacement due to key press
			if (mFwd)    targetKeyDisplacement += forward;
			if (mBwd)    targetKeyDisplacement -= forward;
			if (mLeft)   targetKeyDisplacement += right;
			if (mRight)  targetKeyDisplacement -= right;

			targetKeyDisplacement *= mKeyShiftDown ? mRunningSpeed : mWalkingSpeed;
			targetKeyDisplacement *= dtime;

			// displacement due to game pad control
			targetPadDisplacement += forward * mGamepadForwardInc * mRunningSpeed;
			targetPadDisplacement += right * mGamepadLateralInc * mRunningSpeed;
			targetPadDisplacement *= dtime;

			// compute total displacement due to user input
			disp = targetKeyDisplacement + targetPadDisplacement;

			mSample.mCCTActive = true;
		}
		else
			mSample.mCCTActive = false;

		mSample.bufferCCTMotion(disp, dtime);
	}
	else
		mSample.bufferCCTMotion(PxVec3(0.0f), dtime);

	// Update camera
	mTargetYaw		+= mGamepadYawInc * dtime;
	mTargetPitch	+= mGamepadPitchInc * dtime;

	// Clamp pitch
	if (mTargetPitch < mPitchMin)	mTargetPitch = mPitchMin;
	if (mTargetPitch > mPitchMax)	mTargetPitch = mPitchMax;
	
	mCamera->setRot(PxVec3(-mTargetPitch,-mTargetYaw,0));

	const PxExtendedVec3 camTarget = mController.getPosition();
	const PxVec3 target = PxVec3((PxReal)camTarget.x,(PxReal)camTarget.y,(PxReal)camTarget.z)
						- mCamera->getViewDir()*7.0f;
	mCamera->setPos(target);	
}

#endif // PX_USE_CLOTH_API

